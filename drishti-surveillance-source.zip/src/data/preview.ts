// Storage for the Claude-hosted preview: the artifact's shared database and asset store.
// The real website uses http.ts and the Express server instead.
import type { DataSource } from './source'
import type { Appointment, Category, Client, Product } from './types'
import { makeRef, priceItems, validateAppointment } from './types'
import { seedCategories, seedClients, seedProducts } from './seed'

type Use = <T = any>(name: string) => Promise<T | null> // eslint-disable-line @typescript-eslint/no-explicit-any
const use: Use = (name) => ((window as any).claude?.use ? (window as any).claude.use(name) : Promise.resolve(null)) // eslint-disable-line @typescript-eslint/no-explicit-any

const PRODUCTS = 'catalog/main/products'
const CLIENTS = 'catalog/main/clients'
const CATEGORIES = 'catalog/main/categories'

const fallbackProducts: Product[] = seedProducts.map((p, i) => ({ ...p, id: 'seed-p' + i }))
const fallbackClients: Client[] = seedClients.map((c, i) => ({ ...c, id: 'seed-c' + i }))
const fallbackCategories: Category[] = seedCategories.map((c, i) => ({ ...c, id: 'seed-k' + i }))

async function rows<T>(path: string): Promise<T[] | null> {
  const db = await use('db')
  if (!db) return null
  const snap = await db.collection(path).get()
  return snap.docs.map((d: any) => ({ ...d.data(), id: d.id }) as T) // eslint-disable-line @typescript-eslint/no-explicit-any
}

const bySort = <T extends { sort: number; name: string }>(a: T, b: T) => a.sort - b.sort || a.name.localeCompare(b.name)

async function allProducts() {
  const list = await rows<Product>(PRODUCTS)
  return (list && list.length ? list : fallbackProducts).sort(bySort)
}

async function allCategories() {
  const list = await rows<Category>(CATEGORIES)
  return (list && list.length ? list : fallbackCategories).sort(bySort)
}

async function bookingsCollection() {
  const db = await use('db')
  if (!db) throw new Error('Bookings are not available in this preview.')
  return db
}

export const previewSource: DataSource = {
  listProducts: async () => (await allProducts()).filter((p) => p.active),
  listClients: async () => {
    const list = await rows<Client>(CLIENTS)
    return (list && list.length ? list : fallbackClients).sort(bySort)
  },
  listCategories: allCategories,
  canBook: async () => {
    const [db, user] = await Promise.all([use('db'), use<any>('user')]) // eslint-disable-line @typescript-eslint/no-explicit-any
    return Boolean(db && user && (await user.id()))
  },
  createAppointment: async (a) => {
    const problem = validateAppointment(a)
    if (problem) throw new Error(problem)
    const db = await bookingsCollection()
    const user = await use<any>('user') // eslint-disable-line @typescript-eslint/no-explicit-any
    const uid = user ? await user.id() : null
    if (!uid) throw new Error('Please sign in to Claude to book from this preview.')
    const priced = priceItems(a.items, await allProducts())
    const appt: Appointment = {
      ...a,
      id: makeRef(),
      ref: makeRef(),
      items: priced.items,
      total: priced.total,
      status: 'new',
      createdAt: new Date().toISOString(),
    }
    appt.id = appt.ref
    const ref = db.doc('bookings/' + uid)
    const cur = await ref.get()
    const list = cur.exists ? ((cur.data().list as Appointment[]) ?? []) : []
    try {
      await ref.set({ list: [...list, appt] })
    } catch {
      throw new Error('This preview only takes bookings from people with Contributor access. On your live website anyone can book.')
    }
    return { ref: appt.ref, total: appt.total }
  },
  admin: {
    session: async () => {
      const user = await use<any>('user') // eslint-disable-line @typescript-eslint/no-explicit-any
      const admin = Boolean(user && (await user.canEdit()))
      return { admin, usesPassword: false, note: admin ? undefined : 'Only the owner and editors of this preview can manage it.' }
    },
    login: async () => {},
    logout: async () => {},
    listProducts: allProducts,
    saveProduct: async (p) => {
      const db = await use('db')
      if (!db) throw new Error('Saving is not available in this view.')
      const { id, ...body } = p
      const ref = id && !id.startsWith('seed-') ? db.doc(`${PRODUCTS}/${id}`) : db.collection(PRODUCTS).doc()
      await ref.set(body)
      return { ...body, id: ref.id } as Product
    },
    deleteProduct: async (id) => {
      const db = await use('db')
      if (db) await db.doc(`${PRODUCTS}/${id}`).delete()
    },
    saveClient: async (c) => {
      const db = await use('db')
      if (!db) throw new Error('Saving is not available in this view.')
      const { id, ...body } = c
      const ref = id && !id.startsWith('seed-') ? db.doc(`${CLIENTS}/${id}`) : db.collection(CLIENTS).doc()
      await ref.set(body)
      return { ...body, id: ref.id } as Client
    },
    deleteClient: async (id) => {
      const db = await use('db')
      if (db) await db.doc(`${CLIENTS}/${id}`).delete()
    },
    saveCategory: async (c) => {
      const db = await use('db')
      if (!db) throw new Error('Saving is not available in this view.')
      const name = c.name.trim()
      const existing = await allCategories()
      const clash = existing.find((x) => x.name.toLowerCase() === name.toLowerCase() && x.id !== c.id)
      if (clash) throw new Error(`There is already a category called “${clash.name}”.`)
      const before = existing.find((x) => x.id === c.id)
      const ref = c.id && !c.id.startsWith('seed-') ? db.doc(`${CATEGORIES}/${c.id}`) : db.collection(CATEGORIES).doc()
      await ref.set({ name, sort: c.sort })
      if (before && before.name !== name) {
        for (const p of await allProducts()) if (p.category === before.name && !p.id.startsWith('seed-')) await db.doc(`${PRODUCTS}/${p.id}`).update({ category: name })
      }
      return { id: ref.id, name, sort: c.sort }
    },
    deleteCategory: async (c) => {
      const db = await use('db')
      if (!db) return
      const n = (await allProducts()).filter((p) => p.category === c.name).length
      if (n) throw new Error(`Move or delete the ${n} product${n > 1 ? 's' : ''} in “${c.name}” first.`)
      await db.doc(`${CATEGORIES}/${c.id}`).delete()
    },
    listAppointments: async () => {
      const db = await use('db')
      if (!db) return []
      const snap = await db.collection('bookings').get()
      const all: Appointment[] = []
      snap.docs.forEach((d: any) => ((d.data().list as Appointment[]) ?? []).forEach((a) => all.push({ ...a, id: d.id + '|' + a.ref }))) // eslint-disable-line @typescript-eslint/no-explicit-any
      return all.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    },
    setStatus: async (a, status) => {
      const db = await use('db')
      if (!db) return
      const [owner, ref] = a.id.split('|')
      const doc = db.doc('bookings/' + owner)
      const cur = await doc.get()
      const list = ((cur.data()?.list as Appointment[]) ?? []).map((x) => (x.ref === ref ? { ...x, status } : x))
      await doc.set({ list })
    },
    deleteAppointment: async (a) => {
      const db = await use('db')
      if (!db) return
      const [owner, ref] = a.id.split('|')
      const doc = db.doc('bookings/' + owner)
      const cur = await doc.get()
      await doc.set({ list: ((cur.data()?.list as Appointment[]) ?? []).filter((x) => x.ref !== ref) })
    },
    uploadImage: async (file) => {
      const assets = await use<any>('assets') // eslint-disable-line @typescript-eslint/no-explicit-any
      if (!assets) throw new Error('Uploading is only available to editors of this preview.')
      try {
        const r = await assets.upload(file)
        return 'asset:' + r.id
      } catch (e: any) { // eslint-disable-line @typescript-eslint/no-explicit-any
        throw new Error(e?.code === 'too_large' ? 'That image is too large.' : e?.code === 'unsupported_type' ? 'Please choose a JPG, PNG, WebP or SVG image.' : 'Upload failed. Please try again.')
      }
    },
  },
}
