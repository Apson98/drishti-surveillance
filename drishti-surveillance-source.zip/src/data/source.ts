import type { Appointment, AppointmentStatus, Category, Client, NewAppointment, Product } from './types'
import { httpSource } from './http'
import { previewSource } from './preview'

export type AdminSession = {
  admin: boolean
  /** server mode signs in with a password; the Claude preview uses the viewer's edit access */
  usesPassword: boolean
  note?: string
}

export interface DataSource {
  listProducts(): Promise<Product[]>
  listClients(): Promise<Client[]>
  listCategories(): Promise<Category[]>
  createAppointment(a: NewAppointment): Promise<{ ref: string; total: number }>
  /** false when this view cannot take bookings (e.g. a read-only preview) */
  canBook(): Promise<boolean>
  admin: {
    session(): Promise<AdminSession>
    login(password: string): Promise<void>
    logout(): Promise<void>
    listProducts(): Promise<Product[]>
    saveProduct(p: Omit<Product, 'id'> & { id?: string }): Promise<Product>
    deleteProduct(id: string): Promise<void>
    saveClient(c: Omit<Client, 'id'> & { id?: string }): Promise<Client>
    deleteClient(id: string): Promise<void>
    saveCategory(c: Omit<Category, 'id'> & { id?: string }): Promise<Category>
    deleteCategory(c: Category): Promise<void>
    listAppointments(): Promise<Appointment[]>
    setStatus(a: Appointment, status: AppointmentStatus): Promise<void>
    deleteAppointment(a: Appointment): Promise<void>
    uploadImage(file: File): Promise<string>
  }
}

export const data: DataSource = __PREVIEW__ ? previewSource : httpSource

/** Turn a stored image reference into something an <img> can load. */
export function imageUrl(src: string) {
  if (!src) return ''
  if (src.startsWith('asset:')) return '/_blob/' + src.slice(6)
  return src
}
