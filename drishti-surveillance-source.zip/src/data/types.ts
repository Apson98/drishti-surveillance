// Shared by the website, the admin dashboard and the server.

export type Spec = { label: string; value: string }

export type Product = {
  id: string
  name: string
  brand: string
  category: string
  price: number // NPR
  summary: string // one line shown on the card
  description: string // longer text shown in the product details
  specs: Spec[]
  image: string // image URL ("/uploads/…", "seed/…" or "asset:<id>" in the preview)
  active: boolean // hidden from the website when false
  sort: number
}

export type Client = {
  id: string
  name: string
  logo: string
  review: string // testimonial shown under the logo
  reviewer: string // person who gave it, e.g. "Ramesh Shrestha"
  role: string // e.g. "Operations Manager"
  sort: number
}

export type Category = {
  id: string
  name: string
  sort: number
}

export type AppointmentItem = { productId: string; name: string; price: number; qty: number }

export type AppointmentStatus = 'new' | 'confirmed' | 'completed' | 'cancelled'

export type Appointment = {
  id: string
  ref: string // human reference, e.g. DS-261025-4821
  name: string
  phone: string
  email: string
  address: string
  date: string // YYYY-MM-DD
  slot: string
  notes: string
  items: AppointmentItem[]
  total: number
  status: AppointmentStatus
  createdAt: string // ISO
}

export type NewAppointment = Pick<Appointment, 'name' | 'phone' | 'email' | 'address' | 'date' | 'slot' | 'notes'> & {
  items: { productId: string; qty: number }[]
}

export const TIME_SLOTS = ['9:30 – 11:00 AM', '11:00 AM – 1:00 PM', '1:00 – 3:00 PM', '3:00 – 5:00 PM', '5:00 – 6:30 PM']

export const STATUS_LABEL: Record<AppointmentStatus, string> = {
  new: 'New',
  confirmed: 'Confirmed',
  completed: 'Completed',
  cancelled: 'Cancelled',
}

/** Rs 12,345 */
export const npr = (n: number) => 'Rs ' + Math.round(n).toLocaleString('en-IN')

export function makeRef(d = new Date()) {
  const p = (n: number) => String(n).padStart(2, '0')
  return `DS-${String(d.getFullYear()).slice(2)}${p(d.getMonth() + 1)}${p(d.getDate())}-${Math.floor(1000 + Math.random() * 9000)}`
}

/** Price the items against the current catalogue (never trust prices sent by a browser). */
export function priceItems(items: { productId: string; qty: number }[], products: Product[]) {
  const out: AppointmentItem[] = []
  for (const it of items) {
    const p = products.find((x) => x.id === it.productId && x.active)
    const qty = Math.max(1, Math.min(999, Math.floor(Number(it.qty) || 0)))
    if (p) out.push({ productId: p.id, name: p.name, price: p.price, qty })
  }
  return { items: out, total: out.reduce((s, i) => s + i.price * i.qty, 0) }
}

export function validateAppointment(a: Partial<NewAppointment>): string | null {
  if (!a.name || a.name.trim().length < 2) return 'Please enter your name.'
  if (!a.phone || a.phone.replace(/\D/g, '').length < 7) return 'Please enter a phone number we can call.'
  if (a.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a.email)) return 'That email address does not look right.'
  if (!a.address || a.address.trim().length < 3) return 'Please enter the site address.'
  if (!a.date || !/^\d{4}-\d{2}-\d{2}$/.test(a.date)) return 'Please choose a date.'
  if (!a.slot) return 'Please choose a time.'
  return null
}
