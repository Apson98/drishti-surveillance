import type { Category, Client, Product } from './types'

// Starting catalogue. Prices are SAMPLE values: change them in the admin dashboard.
export const seedProducts: Omit<Product, 'id'>[] = [
  {
    name: 'Bullet camera 2 MP',
    brand: 'Hikvision',
    category: 'IP cameras',
    price: 4800,
    summary: 'Outdoor IP camera for gates, walls and parking.',
    description:
      'A weatherproof bullet camera for outdoor walls, gates and parking areas. Clear day and night images, a visible deterrent, and powered over the network cable from a PoE switch or recorder.',
    specs: [
      { label: 'Resolution', value: '2 MP (1080p)' },
      { label: 'Night vision', value: 'IR up to 30 m' },
      { label: 'Housing', value: 'IP67 weatherproof' },
      { label: 'Power', value: 'PoE or 12 V DC' },
    ],
    image: 'seed/products/bullet.webp',
    active: true,
    sort: 1,
  },
  {
    name: 'Turret dome camera 2 MP',
    brand: 'Hikvision',
    category: 'IP cameras',
    price: 4500,
    summary: 'Wide-angle camera for ceilings, shops and corridors.',
    description:
      'A compact turret camera for indoor ceilings and covered outdoor areas. The wide lens covers a whole room or shop floor, and the ball-shaped body is easy to aim during installation.',
    specs: [
      { label: 'Resolution', value: '2 MP (1080p)' },
      { label: 'Lens', value: '2.8 mm wide angle' },
      { label: 'Night vision', value: 'IR up to 30 m' },
      { label: 'Mount', value: 'Ceiling or wall' },
    ],
    image: 'seed/products/turret.webp',
    active: true,
    sort: 2,
  },
  {
    name: 'Wi-Fi pan & tilt camera',
    brand: 'EZVIZ',
    category: 'Wi-Fi cameras',
    price: 5500,
    summary: 'Indoor Wi-Fi camera that turns to see the whole room.',
    description:
      'A plug-and-play Wi-Fi camera for homes, flats and small shops. It pans and tilts to cover the whole room, alerts your phone when it sees a person, and lets you talk through it from the EZVIZ app.',
    specs: [
      { label: 'View', value: '360° pan and tilt' },
      { label: 'Audio', value: 'Two-way talk' },
      { label: 'Alerts', value: 'Motion and human detection' },
      { label: 'Storage', value: 'microSD or cloud' },
    ],
    image: 'seed/products/wifi.webp',
    active: true,
    sort: 3,
  },
  {
    name: 'Network video recorder, 4 channel',
    brand: 'Hikvision',
    category: 'Recorders',
    price: 9500,
    summary: 'Records up to four IP cameras, viewable on your phone.',
    description:
      'Records every IP camera on site to a hard disk, with playback on a monitor or on your phone through the Hik-Connect app. Hard disk sold separately.',
    specs: [
      { label: 'Channels', value: '4 IP cameras' },
      { label: 'Storage', value: '1 SATA hard disk' },
      { label: 'Compression', value: 'H.265+' },
      { label: 'Output', value: 'HDMI and VGA' },
    ],
    image: 'seed/products/nvr.webp',
    active: true,
    sort: 4,
  },
  {
    name: 'PoE switch, 8 port',
    brand: 'Hikvision',
    category: 'Networking',
    price: 8500,
    summary: 'Powers and connects up to eight cameras over one cable each.',
    description:
      'Sends power and data to each camera over a single Ethernet cable, so no separate power point is needed at the camera. Eight PoE ports plus one uplink to the recorder or router.',
    specs: [
      { label: 'Ports', value: '8 PoE + 1 uplink' },
      { label: 'Use', value: 'IP cameras and access points' },
      { label: 'Install', value: 'Plug and play' },
      { label: 'Form', value: 'Desktop or wall' },
    ],
    image: 'seed/products/switch.webp',
    active: true,
    sort: 5,
  },
]

export const seedCategories: Omit<Category, 'id'>[] = [
  { name: 'IP cameras', sort: 1 },
  { name: 'Wi-Fi cameras', sort: 2 },
  { name: 'Recorders', sort: 3 },
  { name: 'Networking', sort: 4 },
]

// Client reviews are SAMPLE text: replace them from the admin panel.
export const seedClients: Omit<Client, 'id'>[] = [
  {
    name: 'Robam Appliances',
    logo: 'seed/clients/robam.png',
    review: 'Drishti covered our showroom and warehouse with cameras that actually show faces clearly. The team finished on schedule and showed our staff how to check footage on their phones.',
    reviewer: 'Showroom Manager',
    role: 'Robam Appliances',
    sort: 1,
  },
  {
    name: 'ABCD',
    logo: 'seed/clients/abcd.png',
    review: 'Neat cabling, no mess left behind, and every camera angle was agreed with us before drilling. We would call them again for our next branch.',
    reviewer: 'Admin Officer',
    role: 'ABCD',
    sort: 2,
  },
  {
    name: 'EFGH',
    logo: 'seed/clients/efgh.png',
    review: 'Our old system had blind spots at the gate. Drishti planned new positions and now the entrance and parking are fully visible, day and night.',
    reviewer: 'Facility Manager',
    role: 'EFGH',
    sort: 3,
  },
  {
    name: 'IJKL',
    logo: 'seed/clients/ijkl.png',
    review: 'They set up our office network and cameras together, so everything runs from one recorder. Support has been quick whenever we called.',
    reviewer: 'IT Coordinator',
    role: 'IJKL',
    sort: 4,
  },
  {
    name: 'MNOP',
    logo: 'seed/clients/mnop.png',
    review: 'Clear quote, genuine Hikvision equipment and a proper handover. Remote viewing works well even when we are out of the valley.',
    reviewer: 'Owner',
    role: 'MNOP',
    sort: 5,
  },
  {
    name: 'QRST',
    logo: 'seed/clients/qrst.png',
    review: 'The site survey was free and genuinely useful. They recommended fewer cameras than we expected, in better places.',
    reviewer: 'Operations Head',
    role: 'QRST',
    sort: 6,
  },
  {
    name: 'UVWX',
    logo: 'seed/clients/uvwx.png',
    review: 'We added access control and attendance along with CCTV. Staff picked it up in a day and the reports save us time every month.',
    reviewer: 'HR Manager',
    role: 'UVWX',
    sort: 7,
  },
  {
    name: 'YZ',
    logo: 'seed/clients/yz.png',
    review: 'Friendly technicians and fast after-sales service. When a camera needed adjusting, they came the next morning.',
    reviewer: 'Branch Manager',
    role: 'YZ',
    sort: 8,
  },
]
