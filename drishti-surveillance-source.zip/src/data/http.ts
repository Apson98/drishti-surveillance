// Talks to the Express server in server/index.ts
import type { DataSource } from './source'

async function call<T>(url: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    credentials: 'same-origin',
    ...init,
    headers: init.body instanceof FormData ? init.headers : { 'content-type': 'application/json', ...(init.headers || {}) },
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.error || `Something went wrong (${res.status}). Please try again.`)
  return body as T
}
const json = (method: string, body?: unknown): RequestInit => ({ method, body: body === undefined ? undefined : JSON.stringify(body) })

export const httpSource: DataSource = {
  listProducts: () => call('/api/products'),
  listClients: () => call('/api/clients'),
  listCategories: () => call('/api/categories'),
  createAppointment: (a) => call('/api/appointments', json('POST', a)),
  canBook: async () => true,
  admin: {
    session: async () => ({ ...(await call<{ admin: boolean }>('/api/admin/me')), usesPassword: true }),
    login: async (password) => void (await call('/api/admin/login', json('POST', { password }))),
    logout: async () => void (await call('/api/admin/logout', json('POST'))),
    listProducts: () => call('/api/admin/products'),
    saveProduct: (p) => (p.id ? call(`/api/admin/products/${p.id}`, json('PUT', p)) : call('/api/admin/products', json('POST', p))),
    deleteProduct: async (id) => void (await call(`/api/admin/products/${id}`, json('DELETE'))),
    saveClient: (c) => (c.id ? call(`/api/admin/clients/${c.id}`, json('PUT', c)) : call('/api/admin/clients', json('POST', c))),
    deleteClient: async (id) => void (await call(`/api/admin/clients/${id}`, json('DELETE'))),
    saveCategory: (c) => (c.id ? call(`/api/admin/categories/${c.id}`, json('PUT', c)) : call('/api/admin/categories', json('POST', c))),
    deleteCategory: async (c) => void (await call(`/api/admin/categories/${c.id}`, json('DELETE'))),
    listAppointments: () => call('/api/admin/appointments'),
    setStatus: async (a, status) => void (await call(`/api/admin/appointments/${a.id}`, json('PATCH', { status }))),
    deleteAppointment: async (a) => void (await call(`/api/admin/appointments/${a.id}`, json('DELETE'))),
    uploadImage: async (file) => {
      const fd = new FormData()
      fd.append('file', file)
      return (await call<{ url: string }>('/api/admin/upload', { method: 'POST', body: fd })).url
    },
  },
}
